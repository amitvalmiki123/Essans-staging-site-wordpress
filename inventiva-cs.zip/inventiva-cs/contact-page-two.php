<?php
/*
Template Name: Contact Us Two
*/

get_header(); 
?>

<style>
  /* ===== Local Page Styles for Exact HTML Match ===== */
  :root {
    --teal: #1f6f6b;
    --teal-dark: #155753;
    --cream: #f7f4ee;
    --ink: #1a1a1a;
    --muted: #6b6b6b;
    --line: #e2ddd3;
  }
  
  .page-hero {
    background: var(--cream);
    padding: 50px 24px 30px;
    text-align: center;
  }
  .page-hero h1 {
    font-weight: 600;
    font-size: 42px;
    margin: 0 0 8px;
    color: var(--ink);
  }
  .page-hero p { color: var(--muted); max-width: 700px; margin: 0 auto; }

  #booking { background: #fff; padding: 50px 24px; }

  .contact-section {
    max-width: 1200px;
    margin: 0 auto;
    display: grid;
    grid-template-columns: 380px 1fr;
    gap: 40px;
    align-items: start;
  }
  .contact-details { position: sticky; top: 24px; }
  .contact-details h2 {
    font-family: 'Times New Roman', serif;
    font-weight: 600; font-size: 32px; margin: 0 0 4px; color: var(--ink);
  }
  .contact-details h3 {
    font-family: 'Times New Roman', serif;
    font-weight: 600; font-size: 20px; margin: 0 0 22px; color: var(--ink);
  }
  .contact-detail-card {
    display: flex; align-items: flex-start; gap: 16px; padding: 18px 0; border-bottom: 1px solid var(--line);
  }
  .contact-detail-card:last-child { border-bottom: 0; }
  .contact-detail-card__icon {
    flex-shrink: 0; width: 52px; height: 52px; border-radius: 50%;
    background: var(--essen-blue); color: #fff; display: inline-flex; align-items: center; justify-content: center;
  }
  body {
	overflow: visible !important;
}
  .contact-detail-card__icon svg { width: 24px; height: 24px; }
  .contact-detail-card__body h4 {
    font-family: 'Times New Roman', serif;
    font-weight: 600; font-size: 18px; margin: 0 0 4px; color: var(--ink);
  }
  .contact-detail-card__body a { color: var(--ink); font-size: 15px; line-height: 1.5; text-decoration: none; }
  .contact-detail-card__body a:hover { color: var(--teal); text-decoration: underline; }
  .contact-detail-card__body p { margin: 0; font-size: 15px; line-height: 1.5; color: var(--ink); }
  .preview-note {
	max-width: 1200px;
	margin: 0 auto 24px;
	background: #eef6f5;
	border-left: 4px solid var(--teal);
	padding: 12px 16px;
	border-radius: 4px;
	font-size: 14px;
	color: var(--ink);
}

  @media (max-width: 900px) {
    .contact-section { grid-template-columns: 1fr; gap: 28px; }
    .contact-details { position: static; }
    .page-hero h1 { font-size: 30px; }
  }

  /* == FORM STYLES == */
  .esn-bf {
    --esn-teal: #1f6f6b;
    --esn-teal-dark: #155753;
    --esn-ink: #1a1a1a;
    --esn-line: #d9d9d9;
    --esn-bg: #ffffff;
    --esn-pink-bg: #fdecef;
    --esn-pink-border: #f3b9c2;
    --esn-pink-text: #c8102e;
    --esn-yellow-bg: #fff6cf;
    --esn-yellow-border: #f1dd7d;
    --esn-radius: 6px;
    --esn-font: 'Times New Roman', serif;
    --esn-serif: 'Playfair Display', Georgia, serif;

    padding: 28px;
    background: var(--esn-bg);
    color: var(--esn-ink);
    font-family: var(--esn-font);
    font-size: 15px;
    line-height: 1.5;
    border: 1px solid var(--esn-line);
    border-radius: 10px;
    box-shadow: 0 6px 30px rgba(0,0,0,0.05);
  }
  .esn-bf *, .esn-bf *::before, .esn-bf *::after { box-sizing: border-box; }
  
  .esn-bf__header { margin-bottom:22px; }
  .esn-bf__title { font-family: var(--esn-serif); font-weight:600; font-size:30px; line-height:1.15; margin:0; color: rgb(0,0,0);font-family: 'Times New Roman', serif;}
  
  .esn-bf__row { display:grid; grid-template-columns:1fr 1fr; gap:18px; margin-bottom:14px; }
  .esn-bf__field { display:flex; flex-direction:column; }
  .esn-bf__label { font-weight:600; font-size:14px; margin-bottom:6px; font-family: Montserrat, sans-serif;}
  .esn-bf__req { color: var(--esn-pink-text); margin-left:2px; }

  .esn-bf__input, .esn-bf__select {
    width:100%; height:44px;
    border:1px solid var(--esn-line); background:#fff;
    border-radius: var(--esn-radius);
    padding: 0 12px; font:inherit; color: var(--esn-ink);
    outline:none; transition: border-color .15s ease, box-shadow .15s ease;font-family: Montserrat, sans-serif;
  }
  .esn-bf__select {
    background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'><path fill='%231a1a1a' d='M6 8 0 0h12z'/></svg>");
    background-repeat:no-repeat; background-position:right 14px center; padding-right:36px;
    appearance:none; -webkit-appearance:none;
  }
  .esn-bf__input:focus, .esn-bf__select:focus {
    border-color: var(--esn-teal);
    box-shadow: 0 0 0 3px rgba(31, 111, 107, 0.15);
  }
  .esn-bf__time-group { display:grid; grid-template-columns:1fr 1fr 1fr; gap:8px; }
  
  /* Fixing CF7 wrapper specific layout */
  .esn-bf__time-group span.wpcf7-form-control-wrap { width: 100%; }
  
  .esn-bf__input[type="date"] {
    background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='%231f6f6b' stroke-width='2'><rect x='3' y='5' width='18' height='16' rx='2'/><path d='M3 9h18M8 3v4M16 3v4'/></svg>");
    background-repeat:no-repeat; background-position:right 12px center; padding-right:40px;
  }

  .esn-bf__notice {
    border:1px solid var(--esn-teal); background:#fff; border-radius:var(--esn-radius);
    padding: 14px 16px 14px 56px; position:relative; margin:18px 0; font-size:14px;
  }
  .esn-bf__notice-icon {
    position:absolute; left:14px; top:14px; width:30px; height:30px;
    border-radius:50%; background:var(--esn-teal); color:#fff;
    display:inline-flex; align-items:center; justify-content:center;
    font-weight:700; font-family:var(--esn-serif); font-style:italic; font-size:18px;
  }
  .esn-bf__notice-title { color: var(--esn-teal); font-weight:700; margin:0 0 4px; font-size:15px; font-family: Montserrat, sans-serif;}
  .esn-bf__notice p { margin:0 0 6px; font-family: Montserrat, sans-serif;}

  .esn-bf__warn {
    background: var(--esn-pink-bg); border:1px solid var(--esn-pink-border);
    border-radius: var(--esn-radius); padding: 12px 14px 12px 56px; position:relative;
    margin:10px 0 18px; font-size:14px;font-family: Montserrat, sans-serif;
  }
  .esn-bf__warn-icon { position:absolute; left:14px; top:50%; transform:translateY(-50%); width:30px; height:30px; background: url(https://essenremedial.com.au/wp-content/uploads/2026/05/esn-bf__warn-icon-1.png);
    background-size: auto;
  display: inline-block;
  background-size: cover;
  font-size: 0;}
  .esn-bf__warn p { margin:0; }
  .esn-bf__warn-strong { color: var(--esn-pink-text); font-weight:700; }

  .esn-bf__confirm { border:1px solid var(--esn-teal); border-radius:var(--esn-radius); padding:14px 16px; margin:14px 0 18px; }
  .esn-bf__confirm-title { color: var(--esn-teal); font-weight:700; margin:0 0 8px; font-size:15px; font-family: Montserrat, sans-serif;}
  
  .esn-bf__checkbox span.wpcf7-list-item { margin: 0; }
  .esn-bf__checkbox label { display:flex; align-items:flex-start; gap:10px; font-size:14px; font-weight:400; cursor:pointer;font-family: Montserrat, sans-serif;}
  .esn-bf__checkbox input[type="checkbox"] { margin-top:3px; width:18px; height:18px; accent-color: var(--esn-teal); flex-shrink:0; }

  .esn-bf__notes { margin:22px 0 14px; font-size:14px; }
  .esn-bf__notes-title { font-weight:700; margin:0 0 6px; font-family: Montserrat, sans-serif;}
  .esn-bf__notes ul { margin:0; padding-left:22px; }
  .esn-bf__notes li { margin-bottom:4px; font-family: Montserrat, sans-serif;}

  .esn-bf__banner {
    background: var(--esn-yellow-bg); border:1px solid var(--esn-yellow-border);
    border-radius: var(--esn-radius); padding:10px 14px 10px 38px;
    position:relative; font-size:14px; margin:12px 0 22px;font-family: Montserrat, sans-serif;
  }
  .esn-bf__banner::before {
    content:""; position:absolute; left:12px; top:50%; transform:translateY(-50%); width:18px; height:18px;
    background: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23d4a000'><path d='M12 2l2.4 6.6L21 9l-5 4.6L17.5 21 12 17.3 6.5 21 8 13.6 3 9l6.6-.4L12 2z'/></svg>") center/contain no-repeat;
  }

  .esn-bf__submit {
    appearance:none; border:0; background: var(--esn-teal); color:#fff;
    font:inherit; font-weight:700; letter-spacing:0.5px; text-transform:uppercase;
    padding:14px 36px; border-radius:4px; cursor:pointer;
    transition: background-color .15s ease;font-family: Montserrat, sans-serif;
  }
  .esn-bf__submit:hover { background: var(--esn-teal-dark); }

  .esn-bf [data-conditional] { display:block; }
  .esn-bf__error { display:none; color: var(--esn-pink-text); font-size:13px; margin-top:6px; }
  .esn-bf__error.is-visible { display:block; }

  @media (max-width: 600px) {
    .esn-bf { padding:20px 16px; }
    .esn-bf__title { font-size:24px; }
    .esn-bf__row { grid-template-columns:1fr; gap:14px; }
  }
</style>

<section class="page-hero spacial-color">
  <h1>Book an Appointment or Contact Us</h1>
  <p>Thank you for reaching out to Essen Remedial Massage. Please leave a message below and a member of our expert team will get in touch with you promptly.</p>
</section>

<main id="booking">

  <section class="contact-section spacial-color">
    <aside class="contact-details">
      <h2>Contact Us</h2>
      <h3>Contact Details:</h3>

      <div class="contact-detail-card">
        <span class="contact-detail-card__icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="5" width="18" height="14" rx="2"/>
            <path d="M3 7l9 6 9-6"/>
          </svg>
        </span>
        <div class="contact-detail-card__body">
          <h4>Email:</h4>
          <a href="mailto:info@essenremedial.com.au">info@essenremedial.com.au</a>
        </div>
      </div>

      <div class="contact-detail-card">
        <span class="contact-detail-card__icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M22 16.92V21a1 1 0 0 1-1.11 1A19.86 19.86 0 0 1 2 4.11 1 1 0 0 1 3 3h4.09a1 1 0 0 1 1 .75l1 4a1 1 0 0 1-.29 1L7.21 10.21a16 16 0 0 0 6.58 6.58l1.46-1.59a1 1 0 0 1 1-.29l4 1a1 1 0 0 1 .75 1z"/>
          </svg>
        </span>
        <div class="contact-detail-card__body">
          <h4>Phone:</h4>
          <a href="tel:0394174095">03 9417 4095</a>
        </div>
      </div>

      <div class="contact-detail-card">
        <span class="contact-detail-card__icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 1 1 18 0z"/>
            <circle cx="12" cy="10" r="3"/>
          </svg>
        </span>
        <div class="contact-detail-card__body">
          <h4>Address:</h4>
          <p>G 268 Keilor Rd,<br>Essendon North,<br>VIC 3041, Australia</p>
        </div>
      </div>
    </aside>

    <div class="form-wrapper">
      <?php 
      // REPLACE "123" WITH YOUR ACTUAL CF7 FORM ID
      echo do_shortcode('[contact-form-7 id="d2b73a9" title="Contact Form Two"]'); 
      ?>
    </div>

  </section>
</main>

<?php
while ( have_posts() ) :
    the_post();
    the_content();
endwhile;
?>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    var form = document.getElementById('esnBookingForm');
    if (!form) return;

    var treatmentSel = form.querySelector('#esn-treatment');
    var weeksInput   = form.querySelector('#esn-weeks');
    var weeksError   = form.querySelector('#esn-weeks-error');

    function show(el) { if(el) el.classList.add('is-visible'); }
    function hide(el) { if(el) el.classList.remove('is-visible'); }

    function syncConditionals() {
      if(!treatmentSel) return;
      var v = treatmentSel.value;
      if(weeksInput) weeksInput.required = (v === 'pregnancy');
      
      var realLymphCheck = form.querySelector('#esn-lymph-confirm input[type="checkbox"]');
      if(realLymphCheck) {
          realLymphCheck.required = (v === 'lymphatic');
      }
      if (v !== 'pregnancy') hide(weeksError);
    }

    if(treatmentSel) {
        treatmentSel.addEventListener('change', syncConditionals);
    }

    if(weeksInput) {
        weeksInput.addEventListener('input', function () {
          var n = parseInt(weeksInput.value, 10);
          if (!isNaN(n) && n < 12) show(weeksError);
          else hide(weeksError);
        });
    }

    // Instead of completely stopping the submit, we only stop it if validation fails.
    // This allows CF7's built-in AJAX submission to handle the actual email sending.
    form.addEventListener('submit', function (e) {
      if(!treatmentSel) return;
      var realLymphCheck = form.querySelector('#esn-lymph-confirm input[type="checkbox"]');

      if (treatmentSel.value === 'pregnancy' && weeksInput) {
        var n = parseInt(weeksInput.value, 10);
        if (isNaN(n) || n < 12) { 
          show(weeksError); 
          weeksInput.focus(); 
          e.preventDefault(); 
          e.stopImmediatePropagation();
          return; 
        }
      }
      
      if (treatmentSel.value === 'lymphatic' && realLymphCheck && !realLymphCheck.checked) {
        realLymphCheck.focus();
        alert('Please confirm the Lymphatic Drainage medical condition statement to continue.');
        e.preventDefault();
        e.stopImmediatePropagation();
        return;
      }
    }, false);

    syncConditionals();
  });
</script>

<?php 
get_footer(); 
?>