<?php
/**
 * The template for displaying the footer.
 *
 * @package          Flatsome\Templates
 * @flatsome-version 3.16.0
 */

global $flatsome_opt;
?>

</main>

<footer id="footer" class="footer-wrapper">

	<?php do_action('flatsome_footer'); ?>

</footer>

</div>

<?php wp_footer(); ?>

<script>
	jQuery(document).ready(function($) {
		$(".read-more").click(function() {
			var parent = $(this).closest("div, section, article");
			
			var moreText = parent.find(".more-text");
			
			moreText.slideToggle(400, function() {
				if (moreText.is(":visible")) {
					parent.find(".read-more").text("Read Less-");
				} else {
					parent.find(".read-more").text("Read More+");
				}
			});
		});
	});
</script>

<script>
jQuery(document).ready(function($) {
    $(document).on('nfFormSubmitResponse', function(e, response) {
      // Optional: check form ID to target a specific form
      // if (response.data.form_id == '1') { ... }

      $('#Contact h2').text('Thank you, we have received your message and one of our friendly team members will be in contact with you shortly.');
    });
  });
</script>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const container = document.querySelector('.pricing-readmore');
    const text = container.querySelector('.pricing-text p');
    const button = container.querySelector('.pricing-readmore-btn');

    const fullText = text.innerHTML;

    // Text ko 2 parts mein divide karna
    const words = text.innerHTML.split(' ');
    const visibleWords = words.slice(0, 35).join(' ');
    const remainingWords = words.slice(35).join(' ');

    text.innerHTML = visibleWords + 
        ' <span class="pricing-extra">' + remainingWords + '</span>';

    button.addEventListener('click', function () {

        container.classList.toggle('expanded');

        if (container.classList.contains('expanded')) {
            button.textContent = 'Read Less';
        } else {
            button.textContent = 'Read More';
        }

    });

});
</script>


</body>
</html>
