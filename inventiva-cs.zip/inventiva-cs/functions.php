<?php
// Add custom Theme Functions here

/**
 * Auto Complete all WooCommerce orders.
 */
add_action( 'woocommerce_thankyou', 'custom_woocommerce_auto_complete_order' );
function custom_woocommerce_auto_complete_order( $order_id ) {
    if ( ! $order_id ) {
        return;
    }

    $order = wc_get_order( $order_id );
    $order->update_status( 'completed' );
}


// Flatsome Lightbox

add_filter( 'flatsome_lightbox_close_btn_inside', '__return_true' );




function essen_register_hero_section_cpt() {
    $labels = array(
        'name'               => 'Hero Sections',
        'singular_name'      => 'Hero Section',
        'menu_name'          => 'Hero Sections',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Hero Section',
        'edit_item'          => 'Edit Hero Section',
        'new_item'           => 'New Hero Section',
        'view_item'          => 'View Hero Section',
        'search_items'       => 'Search Hero Sections',
        'not_found'          => 'No hero sections found',
        'not_found_in_trash' => 'No hero sections found in Trash',
    );

    $args = array(
        'label'               => 'Hero Section',
        'labels'              => $labels,
        'public'              => false,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'menu_icon'           => 'dashicons-cover-image',
        'supports'            => array( 'title' ),
        'has_archive'         => false,
        'publicly_queryable'  => false,
        'exclude_from_search' => true,
        'show_in_rest'        => false,
        'capability_type'     => 'post',
    );

    register_post_type( 'hero_section', $args );
}
add_action( 'init', 'essen_register_hero_section_cpt' );


add_filter( 'acf/settings/save_json', function ( $path ) {
    return get_stylesheet_directory() . '/acf-json';
} );

// Load path — all field group JSON files inside this folder will be loaded.
add_filter( 'acf/settings/load_json', function ( $paths ) {
    unset( $paths[0] ); // remove default path (optional)
    $paths[] = get_stylesheet_directory() . '/acf-json';
    return $paths;
} );

function essen_hero_shortcode( $atts ) {

    $atts = shortcode_atts( array(
        'id' => '',
    ), $atts, 'essen_hero' );

    if ( ! empty( $atts['id'] ) ) {
        $post_id = intval( $atts['id'] );
    } else {
        $latest = get_posts( array(
            'post_type'      => 'hero_section',
            'posts_per_page' => 1,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'fields'         => 'ids',
        ) );
        $post_id = ! empty( $latest ) ? $latest[0] : 0;
    }

    if ( ! $post_id || ! function_exists( 'get_field' ) ) {
        return '<!-- Essen Hero: no hero_section post found or ACF not active -->';
    }

    // ACF fields fetch
    $eyebrow      = get_field( 'hero_eyebrow', $post_id );
    $heading1     = get_field( 'hero_heading_line1', $post_id );
    $heading2     = get_field( 'hero_heading_line2', $post_id );
    $lead_text    = get_field( 'hero_lead_text', $post_id );
    $btn_text     = get_field( 'hero_button_text', $post_id );
    $btn_link     = get_field( 'hero_button_link', $post_id );
    $call_label   = get_field( 'hero_call_label', $post_id );
    $phone_number = get_field( 'hero_phone_number', $post_id );
    $micro_items  = get_field( 'hero_micro_items', $post_id );
    $media_type   = get_field( 'hero_media_type', $post_id ); // 'image' or 'video'
    $hero_image   = get_field( 'hero_image', $post_id );
    $hero_video   = get_field( 'hero_video', $post_id );
    $video_poster = get_field( 'hero_video_poster', $post_id );

    ob_start();
    ?>
    <section class="essen-hero">
        <div class="essen-hero__media">
            <?php if ( $media_type === 'video' && ! empty( $hero_video ) ) : ?>
                <video autoplay muted loop playsinline
                    <?php if ( ! empty( $video_poster ) ) : ?> poster="<?php echo esc_url( $video_poster ); ?>" <?php endif; ?>>
                    <source src="<?php echo esc_url( $hero_video ); ?>" type="video/mp4">
                </video>
            <?php elseif ( $media_type === 'image' && ! empty( $hero_image ) ) : ?>
                <img src="<?php echo esc_url( $hero_image ); ?>" alt="<?php echo esc_attr( $heading1 ); ?>">
            <?php endif; ?>
        </div>

        <div class="essen-hero__wrap">
            <div class="essen-hero__panel">

                <?php if ( $eyebrow ) : ?>
                    <div class="essen-hero__eyebrow"><?php echo esc_html( $eyebrow ); ?></div>
                <?php endif; ?>

                <h1 class="essen-hero__heading">
                    <?php echo esc_html( $heading1 ); ?>
                    <span class="essen-hero__heading-line2"><?php echo esc_html( $heading2 ); ?></span>
                </h1>

                <?php if ( $lead_text ) : ?>
                    <p class="essen-hero__lead"><?php echo esc_html( $lead_text ); ?></p>
                <?php endif; ?>

                <div class="essen-hero__ctas">
                    <?php if ( $btn_text ) : ?>
                        <a class="essen-hero__btn" href="<?php echo esc_url( $btn_link ); ?>">
                            <?php echo esc_html( $btn_text ); ?> <span class="essen-hero__arrow">&rsaquo;</span>
                        </a>
                    <?php endif; ?>

                    <?php if ( $phone_number ) : ?>
                        <span class="essen-hero__call">
                            <?php echo esc_html( $call_label ); ?> <b><?php echo esc_html( $phone_number ); ?></b>
                        </span>
                    <?php endif; ?>
                </div>

                <?php if ( ! empty( $micro_items ) ) : ?>
                    <div class="essen-hero__micro">
                        <?php foreach ( $micro_items as $item ) : ?>
                            <span><?php echo esc_html( $item['item_text'] ); ?></span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode( 'essen_hero', 'essen_hero_shortcode' );

function essen_hero_enqueue_styles() {
    wp_enqueue_style(
        'essen-hero-style',
        get_stylesheet_directory_uri() . '/css/hero-style.css',
        array(),
        '1.0.0'
    );
}
add_action( 'wp_enqueue_scripts', 'essen_hero_enqueue_styles' );







function essen_register_pillar_section_cpt() {
    $labels = array(
        'name'               => 'Pillar Sections',
        'singular_name'      => 'Pillar Section',
        'menu_name'          => 'Pillar Sections',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Pillar Section',
        'edit_item'          => 'Edit Pillar Section',
        'new_item'           => 'New Pillar Section',
        'view_item'          => 'View Pillar Section',
        'search_items'       => 'Search Pillar Sections',
        'not_found'          => 'No pillar sections found',
        'not_found_in_trash' => 'No pillar sections found in Trash',
    );

    $args = array(
        'label'               => 'Pillar Section',
        'labels'              => $labels,
        'public'              => false,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'menu_icon'           => 'dashicons-awards',
        'supports'            => array( 'title' ),
        'has_archive'         => false,
        'publicly_queryable'  => false,
        'exclude_from_search' => true,
        'show_in_rest'        => false,
        'capability_type'     => 'post',
    );

    register_post_type( 'pillar_section', $args );
}
add_action( 'init', 'essen_register_pillar_section_cpt' );

function essen_pillar_get_icon_svg( $key ) {
    $icons = array(
        'shield' => '<svg class="essen-pillars__icon" viewBox="0 0 48 48"><path d="M24 6c-6 4-11 5-15 5v13c0 9 6 15 15 18 9-3 15-9 15-18V11c-4 0-9-1-15-5z"></path><path d="M18 24l4 4 8-8"></path></svg>',
        'heart'  => '<svg class="essen-pillars__icon" viewBox="0 0 48 48"><path d="M24 40s-13-8-13-18a7.5 7.5 0 0 1 13-5 7.5 7.5 0 0 1 13 5c0 10-13 18-13 18z"></path></svg>',
        'drop'   => '<svg class="essen-pillars__icon" viewBox="0 0 48 48"><path d="M24 10c5 5 9 9 9 15a9 9 0 0 1-18 0c0-6 4-10 9-15z"></path><path d="M14 34c4 3 6 4 10 4s6-1 10-4"></path></svg>',
        'pin'    => '<svg class="essen-pillars__icon" viewBox="0 0 48 48"><path d="M24 6a11 11 0 0 0-11 11c0 8 11 25 11 25s11-17 11-25A11 11 0 0 0 24 6z"></path><circle cx="24" cy="17" r="4"></circle></svg>',
        'leaf'   => '<svg class="essen-pillars__icon" viewBox="0 0 48 48"><path d="M10 38C10 20 22 8 40 8c0 18-12 30-30 30z"></path><path d="M10 38c4-10 12-18 22-22"></path></svg>',
        'star'   => '<svg class="essen-pillars__icon" viewBox="0 0 48 48"><path d="M24 6l5.5 12.5L42 20l-9.5 9 2.5 13L24 35l-11 7 2.5-13L6 20l12.5-1.5z"></path></svg>',
    );

    return isset( $icons[ $key ] ) ? $icons[ $key ] : $icons['shield'];
}

function essen_pillars_shortcode( $atts ) {

    $atts = shortcode_atts( array(
        'id' => '',
    ), $atts, 'essen_pillars' );

    if ( ! empty( $atts['id'] ) ) {
        $post_id = intval( $atts['id'] );
    } else {
        $latest = get_posts( array(
            'post_type'      => 'pillar_section',
            'posts_per_page' => 1,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'fields'         => 'ids',
        ) );
        $post_id = ! empty( $latest ) ? $latest[0] : 0;
    }

    if ( ! $post_id || ! function_exists( 'get_field' ) ) {
        return '<!-- Essen Pillars: no pillar_section post found or ACF not active -->';
    }

    $items = get_field( 'pillars_items', $post_id );

    if ( empty( $items ) ) {
        return '';
    }

    ob_start();
    ?>
    <section class="essen-pillars">
        <div class="essen-pillars__wrap">
            <?php foreach ( $items as $item ) : ?>
                <div class="essen-pillars__pil">
                    <?php echo essen_pillar_get_icon_svg( $item['pillar_icon'] ); ?>
                    <b><?php echo esc_html( $item['pillar_title'] ); ?></b>
                    <span><?php echo esc_html( $item['pillar_desc'] ); ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode( 'essen_pillars', 'essen_pillars_shortcode' );
function essen_pillars_enqueue_styles() {
    wp_enqueue_style(
        'essen-pillars-style',
        get_stylesheet_directory_uri() . '/css/pillars-style.css',
        array(),
        '1.0.0'
    );
}
add_action( 'wp_enqueue_scripts', 'essen_pillars_enqueue_styles' );


/**
 * ============================================================
 * LUXURY HERO SECTION — Custom Post Type + Shortcode
 * (matches: eyebrow / 3-line heading / lead text / 2 buttons /
 *  credentials list / right image with frame + floating card /
 *  bottom scroll indicator)
 * ============================================================
 */

function essen_register_luxury_hero_cpt() {
    $labels = array(
        'name'               => 'Luxury Hero Sections',
        'singular_name'      => 'Luxury Hero Section',
        'menu_name'          => 'Luxury Hero',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Luxury Hero',
        'edit_item'          => 'Edit Luxury Hero',
        'new_item'           => 'New Luxury Hero',
        'view_item'          => 'View Luxury Hero',
        'search_items'       => 'Search Luxury Heroes',
        'not_found'          => 'No luxury hero sections found',
        'not_found_in_trash' => 'No luxury hero sections found in Trash',
    );

    $args = array(
        'label'               => 'Luxury Hero Section',
        'labels'              => $labels,
        'public'              => false,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'menu_icon'           => 'dashicons-format-image',
        'supports'            => array( 'title' ),
        'has_archive'         => false,
        'publicly_queryable'  => false,
        'exclude_from_search' => true,
        'show_in_rest'        => false,
        'capability_type'     => 'post',
    );




    register_post_type( 'lux_hero_section', $args );
}
add_action( 'init', 'essen_register_luxury_hero_cpt' );

function essen_luxury_hero_shortcode( $atts ) {

    $atts = shortcode_atts( array(
        'id' => '',
    ), $atts, 'essen_luxury_hero' );

    if ( ! empty( $atts['id'] ) ) {
        $post_id = intval( $atts['id'] );
    } else {
        $latest = get_posts( array(
            'post_type'      => 'lux_hero_section',
            'posts_per_page' => 1,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'fields'         => 'ids',
        ) );
        $post_id = ! empty( $latest ) ? $latest[0] : 0;
    }

    if ( ! $post_id || ! function_exists( 'get_field' ) ) {
        return '<!-- Essen Luxury Hero: no lux_hero_section post found or ACF not active -->';
    }

    // ACF fields fetch
    $eyebrow       = get_field( 'hero_eyebrow', $post_id );
    $heading1      = get_field( 'hero_heading_line1', $post_id );   // e.g. "Feel better."
    $heading2      = get_field( 'hero_heading_line2', $post_id );   // italic middle line, e.g. "Move better."
    $heading3      = get_field( 'hero_heading_line3', $post_id );   // e.g. "Live better."
    $lead_text     = get_field( 'hero_lead_text', $post_id );
    $btn_primary   = get_field( 'hero_btn_primary', $post_id );     // Link field (Request an appointment)
    $btn_secondary = get_field( 'hero_btn_secondary', $post_id );   // Link field (Explore treatments)
    $credentials   = get_field( 'hero_credentials', $post_id );     // Repeater: credential_text
    $hero_image    = get_field( 'hero_image', $post_id );           // Image field
    $card_title    = get_field( 'hero_card_title', $post_id );      // "Care begins with listening."
    $card_desc     = get_field( 'hero_card_desc', $post_id );
    $scroll_text   = get_field( 'hero_scroll_text', $post_id );     // "Discover Essen"
    $scroll_target = get_field( 'hero_scroll_target', $post_id );   // e.g. "#welcome"

    ob_start();
    ?>
    <section class="luxury-hero">
        <div class="shell luxury-hero-grid">

            <div class="luxury-hero-copy">

                <?php if ( $eyebrow ) : ?>
                    <p class="eyebrow"><?php echo esc_html( $eyebrow ); ?></p>
                <?php endif; ?>

                <h1>
                    <?php echo esc_html( $heading1 ); ?><br>
                    <em><?php echo esc_html( $heading2 ); ?></em><br>
                    <?php echo esc_html( $heading3 ); ?>
                </h1>

               <?php if ( $lead_text ) : ?>
    <div class="hero-lead"><?php echo wp_kses_post( $lead_text ); ?></div>
<?php endif; ?>

                <div class="hero-actions">

                    <?php if ( ! empty( $btn_primary['url'] ) ) : ?>
                        <a class="button button-dark button-booking"
                           href="<?php echo esc_url( $btn_primary['url'] ); ?>"
                           <?php echo ! empty( $btn_primary['target'] ) ? 'target="' . esc_attr( $btn_primary['target'] ) . '"' : ''; ?>>
                            <?php echo esc_html( $btn_primary['title'] ); ?>
                        </a>
                    <?php endif; ?>

                    <?php if ( ! empty( $btn_secondary['url'] ) ) : ?>
                        <a class="text-link"
                           href="<?php echo esc_url( $btn_secondary['url'] ); ?>"
                           <?php echo ! empty( $btn_secondary['target'] ) ? 'target="' . esc_attr( $btn_secondary['target'] ) . '"' : ''; ?>>
                            <?php echo esc_html( $btn_secondary['title'] ); ?> <span>&#8599;</span>
                        </a>
                    <?php endif; ?>

                </div>

                <?php if ( ! empty( $credentials ) ) : ?>
                    <div class="hero-credentials" aria-label="Clinic highlights">
                        <?php foreach ( $credentials as $cred ) : ?>
                            <span><?php echo esc_html( $cred['credential_text'] ); ?></span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

            </div>

            <div class="luxury-hero-visual">

                <?php if ( ! empty( $hero_image['url'] ) ) : ?>
                    <div class="luxury-hero-photo"
                         role="img"
                         style="background-image:url('<?php echo esc_url( $hero_image['url'] ); ?>');"
                         aria-label="<?php echo esc_attr( $hero_image['alt'] ? $hero_image['alt'] : $heading1 ); ?>">
                    </div>
                <?php endif; ?>

                <div class="luxury-hero-frame" aria-hidden="true"></div>

                <?php if ( $card_title || $card_desc ) : ?>
                    <div class="luxury-hero-card">
                        <?php if ( $card_title ) : ?>
                            <strong><?php echo esc_html( $card_title ); ?></strong>
                        <?php endif; ?>
                        <?php if ( $card_desc ) : ?>
                            <span><?php echo esc_html( $card_desc ); ?></span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

            </div>

        </div>

        <?php if ( $scroll_text ) : ?>
            <a class="hero-scroll"
               href="<?php echo esc_attr( $scroll_target ? $scroll_target : '#welcome' ); ?>"
               aria-label="Continue to discover Essen">
                <?php echo esc_html( $scroll_text ); ?> <span>&#8595;</span>
            </a>
        <?php endif; ?>

    </section>
    <?php
    return ob_get_clean();
}
add_shortcode( 'essen_luxury_hero', 'essen_luxury_hero_shortcode' );




if( function_exists('acf_add_options_page') ) {
    acf_add_options_page(array(
        'page_title' => 'Treatments Hero Section',
        'menu_title' => 'Treatments Hero',
        'menu_slug'  => 'treatments-hero-options',
        'capability' => 'edit_posts',
        'redirect'   => false,
        'icon_url'   => 'dashicons-images-alt2',
    ));
}

function essen_treatments_hero_shortcode() {
    ob_start();

    $eyebrow    = get_field('th_eyebrow', 'option');
    $line1      = get_field('th_heading_line1', 'option');
    $line2      = get_field('th_heading_line2', 'option');
    $intro      = get_field('th_intro', 'option');
    $call_text  = get_field('th_call_text', 'option');
    $phone      = get_field('th_phone', 'option');
    $gallery    = get_field('th_gallery', 'option');
    ?>

 <section class="treatments-page-hero treatments-hero">
    <div class="shell treatments-page-hero-grid">
        <div>
            <p class="eyebrow">
                <?php echo esc_html($eyebrow); ?>
            </p>

            <h1>
                <?php echo wp_kses_post($line1); ?><br>
                <em><?php echo wp_kses_post($line2); ?></em>
            </h1>
        </div>

        <div>
            <div class="page-intro">
                <?php echo wp_kses_post($intro); ?>
            </div>

            <a class="text-link"
               href="tel:<?php echo esc_attr(preg_replace('/\s+/', '', $phone)); ?>">
                <?php echo esc_html($call_text); ?> <span>↗</span>
            </a>

            <a class="book-now" href="/contact-us/">
                Book Now
            </a>
        </div>
    </div>
</section>

    <?php if ( $gallery ) : ?>
    <section class="treatment-gallery" aria-label="Women’s treatments at Essen">
        <div class="shell treatment-gallery-grid">
            <?php foreach ( $gallery as $item ) :
                $class = !empty($item['css_class']) ? ' ' . esc_attr($item['css_class']) : '';
                $bg    = !empty($item['image']) ? ' style="background-image:url(' . esc_url($item['image']) . ')"' : '';
                $link  = !empty($item['link']) ? esc_url($item['link']) : '';
                $tag   = $link ? 'a' : 'div';
            ?>
                <<?php echo $tag; ?> class="treatment-gallery-image<?php echo $class; ?>"<?php echo $bg; ?><?php echo $link ? ' href="' . $link . '"' : ''; ?>>
                    <span><?php echo esc_html($item['label']); ?></span>
                </<?php echo $tag; ?>>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif;

    return ob_get_clean();
}
add_shortcode('treatments_hero', 'essen_treatments_hero_shortcode');


function essen_treatment_catalog_shortcode() {
    ob_start();

    $items = get_field('tc_items', 'option');

    if ( $items ) : ?>
    <section class="treatment-catalog">
        <div class="shell catalog-list">
            <?php foreach ( $items as $item ) :
                $anchor = !empty($item['anchor_id']) ? esc_attr($item['anchor_id']) : '';
                $link   = !empty($item['link']) ? esc_url($item['link']) : '/contact';
                $image  = !empty($item['image']) ? $item['image'] : null; // array: url, alt, sizes, etc.
            ?>
                <article class="catalog-card" id="<?php echo $anchor; ?>">
                    <?php if ( $image ) : ?>
                        <div class="catalog-image">
                            <div class="catalog-meta">
                        <small><?php echo esc_html($item['category']); ?></small>
                    </div>
                            <img src="<?php echo esc_url($image['url']); ?>"
                                 alt="<?php echo esc_attr($image['alt'] ? $image['alt'] : $item['title']); ?>" />
                        </div>
                    <?php endif; ?>
                    
                    <div>
                        <h2><?php echo esc_html($item['title']); ?></h2>
                        <p><?php echo esc_html($item['description']); ?></p>
                    </div>
                    <div class="catalog-action">
                        <span><?php echo esc_html($item['duration']); ?></span>
                        <a class="round-arrow" href="<?php echo $link; ?>" aria-label="Request <?php echo esc_attr($item['title']); ?>">↗</a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif;

    return ob_get_clean();
}
add_shortcode('treatment_catalog', 'essen_treatment_catalog_shortcode');


// code add by mudassar 

/**
 * Couples / Group Booking form script (jQuery)
 * Sirf "Couples/Group Bookings" page par load hota hai
 */
add_action( 'wp_enqueue_scripts', function () {

    // Page slug agar alag ho to yahan change kar lena
    if ( ! is_page( 'couples-group-bookings' ) ) {
        return;
    }

    wp_enqueue_script( 'jquery' );

    $js = <<<'JS'
jQuery(function ($) {
  var MAX = 15;
  var PRICES = {
    "Remedial Massage": ["45 Minutes ($115)","1 Hour ($135)","75 Minutes ($165)","90 Minutes ($195)","2 Hours ($265)"],
    "Remedial + Lymphatic Massage": ["1 Hour ($175)","75 Minutes ($210)","90 Minutes ($245)","120 Minutes ($315)"],
    "Pregnancy Massage Therapy": ["1 Hour ($145)","75 Minutes ($175)","90 Minutes ($205)","2 Hours ($270)"],
    "Pregnancy + Lymphatic Massage": ["1 Hour ($180)","75 Minutes ($215)","90 Minutes ($255)","120 Minutes ($325)"],
    "Hot Stone Therapy Massage": ["1 Hour ($155)","75 Minutes ($185)","90 Minutes ($210)","2 Hours ($295)"],
    "Lymphatic Drainage Therapy": ["1 Hour ($150)","75 Minutes ($185)","90 Minutes ($215)","2 Hours ($285)"],
    "Deep Tissue Therapeutic Massage": ["45 Minutes ($110)","1 Hour ($125)","75 Minutes ($155)","90 Minutes ($185)","2 Hours ($255)"],
    "Relaxation Massage": ["1 Hour ($115)","75 Minutes ($145)","90 Minutes ($175)","2 Hours ($230)"]
  };
  var PREG = ["Pregnancy Massage Therapy", "Pregnancy + Lymphatic Massage"];
  var LYMPH = "Lymphatic Drainage Therapy";
  var CONCERNS = ["Swelling / fluid retention","Swollen feet / ankles","Heavy / tired legs","Swollen hands","Lower back / hip discomfort","Neck / shoulder tension","General pregnancy aches","Relaxation / wellbeing","Other"];
  var uid = 0;

  var $wrap = $('#esn-people');
  if (!$wrap.length) return;

  var $add  = $('#esn-add-person');
  var $msg  = $('#esn-people-msg');
  var $form = $wrap.closest('form');
  var $type = $form.find('select[name="booking_type"]');
  var $out  = $form.find('textarea[name="people_details"]');
  var $submit = $form.find('.wpcf7-submit');
  var minCount = 0;

  function f($b, name) { return $b.find('[data-f="' + name + '"]'); }
  function cards() { return $wrap.children('.esn-person-card'); }

  function cardHTML(id) {
    var tOpts = '<option value="">Select Treatment</option>' +
      $.map(PRICES, function (v, t) { return '<option>' + t + '</option>'; }).join('');
    var concerns = $.map(CONCERNS, function (c) {
      return '<label><input type="checkbox" class="esn-concern" value="' + c + '"> ' + c + '</label>';
    }).join('');

    return '' +
    '<h3 class="esn-book__person-title"><span class="esn-num"></span><button type="button" class="esn-remove">Remove</button></h3>' +

    '<div class="esn-book__row">' +
      '<div class="esn-book__field"><label class="esn-book__label">Full Name<span class="esn-book__req">*</span></label>' +
      '<input type="text" class="esn-book__input" data-f="name"></div>' +
      '<div class="esn-book__field"><label class="esn-book__label">Gender<span class="esn-book__req">*</span></label>' +
      '<div class="esn-book__radios esn-gender"><label><input type="radio" name="g_' + id + '" value="Male"> Male</label> ' +
      '<label><input type="radio" name="g_' + id + '" value="Female"> Female</label></div></div>' +
    '</div>' +

    '<div class="esn-book__row">' +
      '<div class="esn-book__field"><label class="esn-book__label">Phone<span class="esn-book__req">*</span></label>' +
      '<input type="tel" class="esn-book__input" data-f="phone"></div>' +
      '<div class="esn-book__field"><label class="esn-book__label">Email<span class="esn-book__req">*</span></label>' +
      '<input type="email" class="esn-book__input" data-f="email"></div>' +
    '</div>' +

    '<div class="esn-book__field"><label class="esn-book__label">Treatments<span class="esn-book__req">*</span></label>' +
    '<select class="esn-book__select" data-f="treatment">' + tOpts + '</select></div>' +

    '<div class="esn-book__field esn-dur" style="display:none"><label class="esn-book__label">Duration<span class="esn-book__req">*</span></label>' +
    '<select class="esn-book__select" data-f="duration"></select></div>' +

    '<div class="esn-preg" style="display:none">' +
      '<div class="esn-book__field"><label class="esn-book__label">Pregnancy Massage — How many weeks pregnant are you?</label>' +
      '<input type="number" class="esn-book__input" data-f="weeks" min="0" max="42" placeholder="Enter number of weeks">' +
      '<span class="esn-weeks-err" style="display:none">Pregnancy massage is only available from 12 weeks onwards.</span></div>' +
      '<div class="esn-book__warn"><span class="esn-book__warn-icon">!</span><p>Please note: Pregnancy massage is only available from 12 weeks onwards.<br>' +
      '<span class="esn-book__warn-strong">We are unable to treat clients under 12 weeks pregnant.</span></p></div>' +
      '<div class="esn-book__field"><label class="esn-book__label">Pregnancy Complications or Precautions<span class="esn-book__req">*</span></label>' +
      '<p class="esn-book__help">Have you been advised of any pregnancy complications or precautions?</p>' +
      '<div class="esn-book__radios esn-comp"><label><input type="radio" name="c_' + id + '" value="No"> No</label> ' +
      '<label><input type="radio" name="c_' + id + '" value="Yes"> Yes</label></div></div>' +
      '<div class="esn-book__field esn-cdet" style="display:none"><label class="esn-book__label">Please provide brief details:</label>' +
      '<textarea class="esn-book__input" data-f="cdetails" placeholder="Please provide brief details"></textarea></div>' +
    '</div>' +

    '<div class="esn-lymph esn-book__confirm" style="display:none">' +
      '<h3 class="esn-book__confirm-title">Lymphatic Drainage Therapy — Medical Condition Confirmation</h3>' +
      '<label class="esn-book__checkbox"><input type="checkbox" data-f="lconfirm"> I confirm I do not have any medical condition that would prevent me from receiving Lymphatic Drainage Therapy, or I have obtained medical clearance.</label>' +
    '</div>' +

    '<div class="esn-book__field"><label class="esn-book__label">Main Treatment Concern<span class="esn-book__req">*</span></label>' +
    '<div class="esn-book__checks esn-concerns">' + concerns + '</div></div>' +

    '<div class="esn-book__field"><label class="esn-book__label">Notes / Specific Requests <span class="esn-book__optional">(Optional)</span></label>' +
    '<textarea class="esn-book__input" data-f="notes" placeholder="Any notes or specific requests"></textarea></div>';
  }

  function addCard() {
    if (cards().length >= MAX) return;
    uid++;
    $('<div class="esn-book__person esn-person-card"></div>')
      .html(cardHTML(uid))
      .appendTo($wrap);
  }

  function renumber() {
    cards().each(function (i) {
      var $b = $(this);
      $b.find('.esn-num').text('Person ' + (i + 1));
      $b.find('.esn-remove').toggle(i >= minCount);
    });
    $add.toggle(minCount === 3 && cards().length < MAX);
    compile();
  }

  function updateCard($b, rebuildDuration) {
    var t = f($b, 'treatment').val();
    if (rebuildDuration) {
      var opts = '<option value="">Select Duration</option>' +
        $.map(PRICES[t] || [], function (d) { return '<option>' + d + '</option>'; }).join('');
      f($b, 'duration').html(opts);
    }
    var isPreg = $.inArray(t, PREG) > -1;
    $b.find('.esn-dur').toggle(!!t);
    $b.find('.esn-preg').toggle(isPreg);
    $b.find('.esn-lymph').toggle(t === LYMPH);
    var comp = $b.find('.esn-comp input:checked').val();
    $b.find('.esn-cdet').toggle(isPreg && comp === 'Yes');
    var w = f($b, 'weeks').val();
    $b.find('.esn-weeks-err').toggle(isPreg && w !== '' && Number(w) < 12);
  }

  function compile() {
    var t = '';
    cards().each(function (i) {
      var $b = $(this);
      var tr = f($b, 'treatment').val();
      var isPreg = $.inArray(tr, PREG) > -1;
      var concerns = $b.find('.esn-concern:checked').map(function () { return this.value; }).get().join(', ');

      t += '--- PERSON ' + (i + 1) + ' ---\n' +
           'Name: ' + $.trim(f($b, 'name').val()) + '\n' +
           'Gender: ' + ($b.find('.esn-gender input:checked').val() || '') + '\n' +
           'Phone: ' + $.trim(f($b, 'phone').val()) + '\n' +
           'Email: ' + $.trim(f($b, 'email').val()) + '\n' +
           'Treatment: ' + tr + '\n' +
           'Duration: ' + (f($b, 'duration').val() || '') + '\n';

      if (isPreg) {
        var c = $b.find('.esn-comp input:checked').val() || '';
        t += 'Weeks Pregnant: ' + f($b, 'weeks').val() + '\n' +
             'Pregnancy Complications/Precautions: ' + c +
             (c === 'Yes' ? ' - ' + $.trim(f($b, 'cdetails').val()) : '') + '\n';
      }
      if (tr === LYMPH) {
        t += 'Lymphatic Medical Confirmation: ' + (f($b, 'lconfirm').is(':checked') ? 'Confirmed' : 'Not confirmed') + '\n';
      }
      t += 'Main Treatment Concern: ' + concerns + '\n' +
           'Notes: ' + $.trim(f($b, 'notes').val()) + '\n\n';
    });
    $out.val(t);

    var $first = cards().first();
    var has = $first.length > 0;
    $form.find('input[name="p1_name"]').val(has ? $.trim(f($first, 'name').val()) : '');
    $form.find('input[name="p1_email"]').val(has ? $.trim(f($first, 'email').val()) : '');
    $form.find('input[name="p1_phone"]').val(has ? $.trim(f($first, 'phone').val()) : '');
  }

  function setType() {
    var v = $type.val() || '';
    minCount = v.indexOf('Couples') === 0 ? 2 : (v.indexOf('Group') === 0 ? 3 : 0);
    if (minCount === 2 || minCount === 0) {
      cards().slice(minCount).remove();
    }
    while (cards().length < minCount) addCard();
    renumber();
  }

  $type.on('change', setType);
  $add.on('click', function () { addCard(); renumber(); });

  $wrap.on('click', '.esn-remove', function () {
    $(this).closest('.esn-person-card').remove();
    renumber();
  });

  $wrap.on('change', 'select, input, textarea', function () {
    var $b = $(this).closest('.esn-person-card');
    updateCard($b, $(this).attr('data-f') === 'treatment');
    compile();
  });
  $wrap.on('input', 'input, textarea', function () {
    var $b = $(this).closest('.esn-person-card');
    updateCard($b, false);
    compile();
  });

  // Submit se pehle sab persons ki required fields check
  if ($submit.length) {
    $submit[0].addEventListener('click', function (e) {
      var $list = cards();
      if (!$list.length) return;
      compile();
      var bad = false;
      function flag($el, isBad) { $el.toggleClass('esn-err', isBad); if (isBad) bad = true; }

      $list.each(function () {
        var $b = $(this);
        var t = f($b, 'treatment').val();
        var isPreg = $.inArray(t, PREG) > -1;

        $.each(['name', 'phone', 'email', 'treatment', 'duration'], function (_, n) {
          flag(f($b, n), !$.trim(f($b, n).val() || ''));
        });
        var em = $.trim(f($b, 'email').val());
        if (em && !/^\S+@\S+\.\S+$/.test(em)) flag(f($b, 'email'), true);

        flag($b.find('.esn-gender'), !$b.find('.esn-gender input:checked').length);
        flag($b.find('.esn-concerns'), !$b.find('.esn-concern:checked').length);

        if (isPreg) {
          flag($b.find('.esn-comp'), !$b.find('.esn-comp input:checked').length);
          var w = f($b, 'weeks').val();
          flag(f($b, 'weeks'), w !== '' && Number(w) < 12);
        }
        if (t === LYMPH) flag($b.find('.esn-lymph'), !f($b, 'lconfirm').is(':checked'));
      });

      $msg.toggle(bad);
      if (bad) {
        e.preventDefault();
        e.stopImmediatePropagation();
        $msg[0].scrollIntoView({ block: 'center', behavior: 'smooth' });
      }
    }, true);
  }

  // Mail successfully send hone ke baad cards clear
  $(document).on('wpcf7mailsent', function (ev) {
    if ($form.closest('.wpcf7').is(ev.target) || $.contains($form.closest('.wpcf7')[0], ev.target)) {
      $wrap.empty();
      minCount = 0;
      renumber();
    }
  });

  renumber();
});
JS;

    wp_add_inline_script( 'jquery', $js );
} );